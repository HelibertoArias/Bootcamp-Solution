﻿namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ITradeParser
    {
        List<TradeRecord> Parse(List<string> lines);
    }
}