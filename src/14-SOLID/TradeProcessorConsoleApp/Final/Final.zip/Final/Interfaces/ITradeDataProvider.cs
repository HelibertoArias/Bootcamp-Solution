﻿using System.Collections.Generic;

namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ITradeDataProvider
    {
        List<string> GetTradeData();
    }
}