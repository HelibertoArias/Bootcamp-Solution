﻿namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ITradeMapper
    {
        TradeRecord Map(string[] fields);
    }
}