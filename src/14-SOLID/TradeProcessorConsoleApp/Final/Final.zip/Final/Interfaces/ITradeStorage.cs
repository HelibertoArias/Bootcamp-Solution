﻿namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ITradeStorage
    {
        void Persist(List<TradeRecord> trades);
    }
}