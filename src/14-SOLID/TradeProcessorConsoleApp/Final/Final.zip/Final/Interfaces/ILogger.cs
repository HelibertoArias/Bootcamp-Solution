﻿namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ILogger
    {
        void LogWarning(string message, params object[] args);

        void LogInfo(string message, params object[] args);
    }
}