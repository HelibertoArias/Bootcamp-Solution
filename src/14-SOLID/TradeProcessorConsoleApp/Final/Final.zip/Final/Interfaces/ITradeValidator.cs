﻿namespace TradeProcessorConsoleApp.Final.Interfaces
{
    public interface ITradeValidator
    {
        bool Validate(string[] tradeData);
    }
}