﻿using TradeProcessorConsoleApp.Final.Interfaces;

namespace TradeProcessorConsoleApp.Final
{
    public class StreamTradeDataProvider : ITradeDataProvider
    {
        private Stream stream;

        public StreamTradeDataProvider(Stream stream)
        {
            this.stream = stream;
        }

        public List<string> GetTradeData()
        {
            var lines = new List<string>();
            using (var reader = new StreamReader(stream))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    lines.Add(line);
                }
            }

            return lines;
        }
    }
}