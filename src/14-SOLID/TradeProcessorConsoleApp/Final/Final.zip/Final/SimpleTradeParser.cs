﻿using TradeProcessorConsoleApp.Final.Interfaces;

namespace TradeProcessorConsoleApp.Final
{
    public class SimpleTradeParser : ITradeParser
    {
        private ITradeValidator tradeValidator;
        private ITradeMapper tradeMapper;

        public SimpleTradeParser(ITradeValidator tradeValidator, ITradeMapper tradeMapper)
        {
            this.tradeValidator = tradeValidator;
            this.tradeMapper = tradeMapper;
        }

        public List<TradeRecord> Parse(List<string> lines)
        {
            var trades = new List<TradeRecord>();

            var lineCount = 1;
            foreach (var line in lines)
            {
                var fields = line.Split(new char[] { ',' });

                if (!tradeValidator.Validate(fields))
                {
                    continue;
                }

                TradeRecord trade = tradeMapper.Map(fields);

                trades.Add(trade);

                lineCount++;
            }

            return trades;
        }
    }
}