﻿using System;
using TradeProcessorConsoleApp.Final.Interfaces;

namespace TradeProcessorConsoleApp.Final
{
    internal class ConsoleLogger : ILogger
    {
        public void LogInfo(string message, params object[] args) => Console.WriteLine(string.Concat("Info ", message), args);

        public void LogWarning(string message, params object[] args) => Console.WriteLine(string.Concat("Warning ", message), args);
    }
}